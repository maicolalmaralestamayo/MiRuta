<?php

/*
| Configuración de MiRuta en el hospedaje.
|
| Es un archivo PHP: el servidor web nunca muestra su contenido. Edítelo con
| FileZilla (botón derecho > Ver/Editar) y vuelva a subirlo.
|
| IMPORTANTE: guarde una copia de APP_KEY, JWT_SECRET y MAINTENANCE_KEY. Si
| cambian, se cierran todas las sesiones (APP_KEY y JWT_SECRET) o deja de
| servir la clave de mantenimiento.
*/

return [
    'APP_NAME' => 'MiRuta',
    'APP_ENV' => 'production',
    'APP_DEBUG' => false,
    'APP_URL' => 'http://www.twintechnology.cu/miruta',
    'APP_TIMEZONE' => 'America/Havana',
    'APP_LOCALE' => 'es',

    // Claves secretas (generadas al preparar el paquete).
    'APP_KEY' => 'base64:2bIX1sASr952j+T5QglNoirDsk5QBnPnItyyJyNvJZo=',
    'JWT_SECRET' => 'f906f98a83135194ec320b140ef313eeec1772a78c0e2318c333db2cc79e4d2c',

    // Clave de mantenimiento: para instalar o actualizar la base de datos
    // desde la app (Servidor > Mantenimiento) sin iniciar sesión.
    'MAINTENANCE_KEY' => 'gPx8Y9Lr3jzxWJCX7rFlZWgG',

    // Base de datos (MariaDB 10.3 o superior, o MySQL 5.7 / 8).
    'DB_CONNECTION' => 'mysql',
    'DB_HOST' => 'CAMBIAR',
    'DB_PORT' => '3306',
    'DB_DATABASE' => 'CAMBIAR',
    'DB_USERNAME' => 'CAMBIAR',
    'DB_PASSWORD' => 'CAMBIAR',

    // Carpeta de trabajo (caché, registro de errores) fuera de la parte
    // pública, y carpeta temporal del hospedaje.
    'STORAGE_PATH' => '/srv/www/www.twintechnology.cu/tmp/miruta',
    'TEMP_PATH' => '/srv/www/www.twintechnology.cu/tmp',

    // Sin cron: las tareas programadas se ejecutan con las peticiones.
    'TASKS_ON_REQUESTS' => true,

    'CACHE_STORE' => 'file',
    'LOG_CHANNEL' => 'single',
    'DOCS_ENABLED' => false,
];
